<?php

@include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>about</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php @include 'header.php'; ?>

<section class="heading">
    <h3>about us</h3>
    <p> <a href="home.php">home</a> / about </p>
</section>

<section class="about">

    <div class="flex">

        <div class="image">
            <img src="images/ceaf.png" alt="">
        </div>

        <div class="content">
            <h3>why choose us?</h3>
            <p>Because we craft each scoop with passion and precision, ensuring every bite is a taste of perfection. Experience the difference in every delightful swirl.</p>
            <a href="shop.php" class="btn">shop now</a>
        </div>

    </div>

    <div class="flex">

        <div class="content">
            <h3>what we provide?</h3>
            <p>At our ice cream shop, we provide more than just treats; we offer a symphony of flavors, a haven of indulgence, and a sprinkle of joy in every scoop. From classic favorites to innovative creations, we're here to elevate your ice cream experience and create unforgettable memories, one delicious cone at a time.</p>
            <a href="contact.php" class="btn">contact us</a>
        </div>

        <div class="image">
            <img src="images/form.png" alt="">
        </div>

    </div>

    <div class="flex">

        <div class="image">
            <img src="images/about.png" alt="">
        </div>

        <div class="content">
            <h3>who we are?</h3>
            <p>We are more than just an ice cream shop; we're a passionate team dedicated to delighting taste buds and creating moments of happiness. With a commitment to quality, creativity, and customer satisfaction, we strive to be your go-to destination for all things sweet and satisfying. Join us on a journey of flavor and fun, where every visit leaves you craving more.</p>
            <a href="#reviews" class="btn">clients reviews</a>
        </div>

    </div>

</section>

<section class="reviews" id="reviews">

    <h1 class="title">client's reviews</h1>

    <div class="box-container">

        <div class="box">
            <img src="images/pic-1.png" alt="">
            <p>Absolutely love the variety of flavors! From classic vanilla to exotic mango habanero, there's something for everyone. Each scoop is a little taste of heaven!</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>John deol</h3>
        </div>

        <div class="box">
            <img src="images/pic-2.png" alt="">
            <p>Incredible service and delicious ice cream! The staff are always friendly and welcoming, making every visit a treat. My favorite spot for indulgence!</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Nisha Gupta</h3>
        </div>

        <div class="box">
            <img src="images/pic-3.png" alt="">
            <p>Hands down the best ice cream in town! Creamy, flavorful, and always fresh. Every visit feels like a celebration! Its just amazing and family Friendly must recomanded! </p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Peater Parker</h3>
        </div>

        <div class="box">
            <img src="images/pic-4.png" alt="">
            <p>What a gem! The quality of their ice cream is unmatched, and the ambiance is so inviting. A must-visit for any ice cream enthusiast and i love coming here again and again!</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Ananya Mehta</h3>
        </div>

        <div class="box">
            <img src="images/pic-5.png" alt="">
            <p>Wow! Just wow! The attention to detail in every flavor is remarkable. I'm constantly impressed by the creativity and taste. My taste buds thank you!</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Aarav Patel</h3>
        </div>

        <div class="box">
            <img src="images/pic-6.png" alt="">
            <p>A true delight! The passion for ice cream shines through in every bite. I've tried many flavors, and each one is better than the last. Simply delicious!</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Priya Sharma</h3>
        </div>

    </div>

</section>











<?php @include 'footer.php'; ?>

<script src="js/script.js"></script>

</body>
</html>