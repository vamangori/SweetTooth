-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 11, 2024 at 05:30 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `iceshop_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `pid` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` int(100) NOT NULL,
  `quantity` int(100) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `pid`, `name`, `price`, `quantity`, `image`) VALUES
(139, 17, 31, 'Caramel Swirl Sensation', 349, 1, 'categories.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `number` varchar(12) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`id`, `user_id`, `name`, `email`, `number`, `message`) VALUES
(14, 17, 'abc', 'abc@xyz.com', '9685741203', 'sdfb ckjc casckasjb cb nxkhcb ask a');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `number` varchar(12) NOT NULL,
  `email` varchar(100) NOT NULL,
  `method` varchar(50) NOT NULL,
  `address` varchar(500) NOT NULL,
  `total_products` varchar(1000) NOT NULL,
  `total_price` int(100) NOT NULL,
  `placed_on` varchar(50) NOT NULL,
  `payment_status` varchar(20) NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `name`, `number`, `email`, `method`, `address`, `total_products`, `total_price`, `placed_on`, `payment_status`) VALUES
(19, 17, 'test', '9685742130', 'test@123.com', 'cash on delivery', 'flat no. hfd gfc xaj kbk sc s khbc, mc  cc c vk xc sfb zx, nc cb , cnsjcn s - 745222', ', Divine Chocolate Delight (1) , Salted Caramel Crunch (1) , Raspberry Sorbet Sparkle (1) ', 1109, '05-Apr-2024', 'completed');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `details` varchar(500) NOT NULL,
  `price` int(100) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `details`, `price`, `image`) VALUES
(21, 'Divine Chocolate Delight', 'Indulge in the rich, creamy goodness of our Divine Chocolate Delight. Made with premium cocoa and velvety smooth texture, it\'s a chocolate lover\'s dream come true.', 250, 'mission0.jpg'),
(22, 'Tropical Mango Tango', 'Experience a burst of tropical flavor with our Tropical Mango Tango. Made with ripe, juicy mangoes sourced from exotic orchards, each spoonful is a refreshing delight.', 170, 'type5.png'),
(23, 'Classic Vanilla Bean', 'Savor the timeless elegance of our Classic Vanilla Bean. Made with real Madagascar vanilla beans, it\'s a creamy and aromatic treat that never goes out of style.', 230, 'categories1.jpg'),
(24, 'Berrylicious Bliss', 'Dive into a berry-filled paradise with our Berrylicious Bliss. Packed with a medley of strawberries, blueberries, and raspberries, it\'s a fruity explosion in every bite.', 350, 'sub-banner.png'),
(25, 'Salted Caramel Crunch', 'Indulge in the perfect balance of sweet and salty with our Salted Caramel Crunch. Rich caramel swirled into creamy ice cream, complemented by crunchy caramel pieces – it\'s a symphony of flavors.', 400, '514215896_012c012ccc@2x.jpg'),
(26, 'Nutty Pistachio Perfection', 'Treat yourself to the nutty goodness of our Nutty Pistachio Perfection. Made with real pistachios and a hint of almond, it\'s a smooth and irresistible delight for nut lovers.', 380, '518151488_012c012ccc@2x.jpg'),
(27, 'Cookie Dough Delight', 'Indulge in the nostalgia of childhood with our Cookie Dough Delight. Creamy vanilla ice cream swirled with chunks of cookie dough and chocolate chips – it\'s a comforting classic.', 420, 'sub-banner-img.png'),
(28, 'Coconut Paradise', 'Escape to the tropics with our Coconut Paradise. Creamy coconut-flavored ice cream blended with shredded coconut flakes, transporting you to sun-kissed beaches with every spoonful.', 349, '687180662_012c012ccc@2x.jpg'),
(29, 'Hazelnut Heaven', 'Elevate your taste buds with our Hazelnut Heaven. Luxuriously smooth hazelnut ice cream infused with rich cocoa, creating a divine flavor experience reminiscent of a gourmet dessert.', 469, '687180636_012c012ccc@2x.jpg'),
(30, 'Minty Chocolate Dream', 'Refresh your palate with our Minty Chocolate Dream. Cool and creamy mint ice cream swirled with decadent chocolate fudge, offering a perfect balance of freshness and indulgence.', 399, 'product5.jpg'),
(31, 'Caramel Swirl Sensation', 'Dive into a whirlwind of flavor with our Caramel Swirl Sensation. Creamy caramel ice cream infused with ribbons of caramel sauce, creating a lusciously sweet and smooth treat.', 349, 'categories.jpg'),
(32, 'Raspberry Sorbet Sparkle', 'Experience a burst of tangy sweetness with our Raspberry Sorbet Sparkle. Made with ripe raspberries and a hint of lemon, it\'s a refreshing sorbet that\'s perfect for a sunny day.', 459, 'categories2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `user_type` varchar(20) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `user_type`) VALUES
(10, 'admin A', 'admin01@gmail.com', '698d51a19d8a121ce581499d7b701668', 'admin'),
(14, 'user A', 'user01@gmail.com', '698d51a19d8a121ce581499d7b701668', 'user'),
(15, 'user B', 'user02@gmail.com', '698d51a19d8a121ce581499d7b701668', 'user'),
(16, 'test', 'test@123.com', 'cc03e747a6afbbcbf8be7668acfebee5', 'admin'),
(17, 'abc', 'abc@xyz.com', '202cb962ac59075b964b07152d234b70', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `pid` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` int(100) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=140;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
